/**
 * Smart Jurnal Visual Engine
 * — particle field + mouse parallax + soft motion
 */
(function () {
  const canvas = document.createElement('canvas');
  canvas.id = 'jg-engine-canvas';
  Object.assign(canvas.style, {
    position: 'fixed',
    inset: '0',
    width: '100%',
    height: '100%',
    zIndex: '0',
    pointerEvents: 'none'
  });
  document.body.prepend(canvas);

  const ctx = canvas.getContext('2d');
  let w = 0, h = 0, dpr = 1;
  let mouse = { x: 0.5, y: 0.5, tx: 0.5, ty: 0.5 };
  let scrollY = 0;
  const particles = [];
  const PARTICLE_COUNT = 48;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = window.innerWidth;
    h = window.innerHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spawn() {
    particles.length = 0;
    for (let i = 0; i < PARTICLE_COUNT; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        r: 1.2 + Math.random() * 2.8,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        a: 0.15 + Math.random() * 0.35,
        hue: 210 + Math.random() * 40
      });
    }
  }

  function tick() {
    mouse.x += (mouse.tx - mouse.x) * 0.06;
    mouse.y += (mouse.ty - mouse.y) * 0.06;

    ctx.clearRect(0, 0, w, h);

    // soft gradient wash following mouse
    const gx = mouse.x * w;
    const gy = mouse.y * h;
    const grad = ctx.createRadialGradient(gx, gy, 0, gx, gy, Math.max(w, h) * 0.55);
    grad.addColorStop(0, 'rgba(37,99,235,0.08)');
    grad.addColorStop(0.45, 'rgba(14,165,233,0.04)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // particles
    for (const p of particles) {
      p.x += p.vx + (mouse.x - 0.5) * 0.15;
      p.y += p.vy + (mouse.y - 0.5) * 0.1 + scrollY * 0.00015;
      if (p.x < -20) p.x = w + 20;
      if (p.x > w + 20) p.x = -20;
      if (p.y < -20) p.y = h + 20;
      if (p.y > h + 20) p.y = -20;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `hsla(${p.hue}, 80%, 55%, ${p.a})`;
      ctx.fill();
    }

    // connection lines near mouse
    const mx = mouse.x * w;
    const my = mouse.y * h;
    for (let i = 0; i < particles.length; i++) {
      const a = particles[i];
      const dx = a.x - mx;
      const dy = a.y - my;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 140) {
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(mx, my);
        ctx.strokeStyle = `rgba(37,99,235,${(1 - dist / 140) * 0.2})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    requestAnimationFrame(tick);
  }

  window.addEventListener('mousemove', e => {
    mouse.tx = e.clientX / w;
    mouse.ty = e.clientY / h;
  }, { passive: true });

  window.addEventListener('scroll', () => {
    scrollY = window.scrollY || 0;
  }, { passive: true });

  window.addEventListener('resize', () => {
    resize();
    spawn();
  });

  // interactive CSS blobs if present
  function bindBlobs() {
    const blobs = document.querySelectorAll('.blob');
    if (!blobs.length) return;
    window.addEventListener('mousemove', e => {
      const nx = (e.clientX / window.innerWidth - 0.5) * 2;
      const ny = (e.clientY / window.innerHeight - 0.5) * 2;
      blobs.forEach((b, i) => {
        const depth = (i + 1) * 12;
        const sy = (window.scrollY || 0) * (parseFloat(b.dataset.speed) || 0.2);
        b.style.transform = `translate3d(${nx * depth}px, ${ny * depth + sy}px, 0)`;
      });
    }, { passive: true });
  }

  function init() {
    resize();
    spawn();
    tick();
    bindBlobs();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
