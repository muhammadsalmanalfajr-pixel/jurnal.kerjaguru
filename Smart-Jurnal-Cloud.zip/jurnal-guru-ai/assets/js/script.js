/**
 * Smart Jurnal — Multi-page + Parallax
 * Data: localStorage | AI: lokal (siap diganti API)
 */


/* ===== AUTH + CLOUD DATA ===== */
async function getAuth() {
  try {
    const user = await getSessionUser();
    if (!user) return null;
    const { data: profile } = await sb.from('profiles').select('id,email,name,role,status').eq('id', user.id).single();
    if (!profile || profile.status !== 'active') return null;
    return { ...profile, role: profile.role || 'guru', userId: user.id };
  } catch { return null; }
}

async function requireGuru() {
  const auth = await SmartJurnalAuth.requireAuth(['guru','admin']);
  if (!auth) return false;
  if (auth.profile.role === 'admin') {
    const page = location.pathname.split('/').pop();
    if (page !== 'admin.html') location.replace('../admin.html');
    return false;
  }
  return true;
}

async function logout() { await sb.auth.signOut(); location.replace(new URL('../login.html', location.href).href); }
window.logout = logout;
window.getAuth = getAuth;

const STORAGE_KEYS = { siswa: 'siswa', jurnal: 'jurnal', kegiatan: 'kegiatan', nilai: 'nilai' };
let state = { siswa: [], jurnal: [], kegiatan: [], nilai: [], teacher: 'Guru' };
window.state = state;
async function buatKodeWali(siswaId){
  const auth=await getAuth(); if(!auth||auth.role!=='guru') return;
  const code='WALI-'+Math.random().toString(36).slice(2,8).toUpperCase();
  const {error}=await sb.from('wali_access').insert({owner_id:auth.userId,student_id:siswaId,access_code:code});
  if(error){alert(error.message);return null;}
  alert('Kode wali: '+code); return code;
}
window.buatKodeWali=buatKodeWali;


async function loadState() {
  const auth = await getAuth();
  if (!auth) return;
  try {
    const { data, error } = await sb.from('app_records').select('kind,record_id,data').eq('owner_id', auth.userId);
    if (error) throw error;
    state.siswa = (data||[]).filter(r=>r.kind==='siswa').map(r=>({...(r.data||{}), id:r.record_id}));
    state.jurnal = (data||[]).filter(r=>r.kind==='jurnal').map(r=>({...(r.data||{}), id:r.record_id}));
    state.kegiatan = (data||[]).filter(r=>r.kind==='kegiatan').map(r=>({...(r.data||{}), id:r.record_id}));
    state.nilai = (data||[]).filter(r=>r.kind==='nilai').map(r=>({...(r.data||{}), id:r.record_id}));
    state.teacher = auth.name || auth.email || 'Guru';
  } catch (e) { console.error('Gagal memuat data cloud', e); alert('Gagal memuat data dari server. Periksa koneksi Supabase.'); }
  window.state = state;
}
window.loadState = loadState;

async function save(key, data) {
  const auth = await getAuth();
  if (!auth) return;
  const kind = Object.entries(STORAGE_KEYS).find(([,v])=>v===key)?.[0] || key;
  const rows = (data||[]).map(item => ({ owner_id: auth.userId, kind, record_id: item.id || uid(), data: item }));
  try {
    const { error: delError } = await sb.from('app_records').delete().eq('owner_id', auth.userId).eq('kind', kind);
    if (delError) throw delError;
    if (rows.length) {
      const { error } = await sb.from('app_records').insert(rows);
      if (error) throw error;
    }
  } catch(e) { console.error(e); alert('Data gagal disinkronkan.'); }
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(d) {
  if (!d) return '-';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderList(containerId, items, emptyText, renderer) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (!items.length) {
    el.innerHTML = `<div class="empty">${emptyText}</div>`;
    return;
  }
  el.innerHTML = items.map(renderer).join('');
}

/* ===== PARALLAX ===== */
function initParallax() {
  const blobs = document.querySelectorAll('.blob');
  if (!blobs.length) return;

  let ticking = false;

  function update() {
    const scrollY = window.scrollY || window.pageYOffset;
    blobs.forEach(blob => {
      const speed = parseFloat(blob.dataset.speed) || 0.3;
      const y = scrollY * speed;
      blob.style.transform = `translate3d(0, ${y}px, 0)`;
    });
    ticking = false;
  }

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(update);
      ticking = true;
    }
  }, { passive: true });

  // initial
  update();
}

/* ===== SISWA ===== */
function renderSiswa(filter = '') {
  let data = [...state.siswa];
  if (filter) {
    const q = filter.toLowerCase().trim();
    data = data.filter(s => {
      const nama = (s.nama || '').toLowerCase();
      const kelas = (s.kelas || '').toLowerCase();
      const nik = (s.nik || '').toLowerCase();
      return nama.includes(q) || kelas.includes(q) || nik.includes(q);
    });
  }

  renderList('listSiswa', data, filter ? 'Tidak ada siswa yang cocok.' : 'Belum ada data siswa. Tambahkan dulu.', s => `
    <div class="list-item">
      <div>
        <div class="title">${escapeHtml(s.nama)}</div>
        <div class="meta">Kelas: ${escapeHtml(s.kelas)}</div>
      </div>
      <div class="actions">
        <button class="btn-danger" onclick="hapusSiswa('${s.id}')">Hapus</button>
      </div>
    </div>
  `);

  const select = document.getElementById('jurnalSiswa');
  if (select) {
    select.innerHTML = '<option value="">-- Pilih Siswa --</option>' +
      state.siswa.map(s => `<option value="${s.id}">${escapeHtml(s.nama)} (${escapeHtml(s.kelas)})</option>`).join('');
  }

  const stat = document.getElementById('statSiswa');
  if (stat) stat.textContent = state.siswa.length;
}

function tambahSiswa(e) {
  e.preventDefault();
  const nama = document.getElementById('siswaNama').value.trim();
  const kelas = document.getElementById('siswaKelas').value.trim();
  if (!nama || !kelas) return;

  state.siswa.push({ id: uid(), nama, kelas });
  save(STORAGE_KEYS.siswa, state.siswa);
  document.getElementById('formSiswa').reset();
  renderSiswa(document.getElementById('searchSiswa')?.value || '');
}

function hapusSiswa(id) {
  if (!confirm('Hapus siswa ini? Jurnal terkait tidak ikut terhapus.')) return;
  state.siswa = state.siswa.filter(s => s.id !== id);
  save(STORAGE_KEYS.siswa, state.siswa);
  renderSiswa();
}

/* ===== JURNAL ===== */
function nilaiClass(n) {
  if (n === 'Sangat Baik' || n === 'Baik') return 'success';
  if (n === 'Cukup') return 'warning';
  return 'danger';
}

function renderJurnal(filter = '') {
  let data = [...state.jurnal].sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  if (filter) {
    const q = filter.toLowerCase();
    data = data.filter(j => {
      const siswa = state.siswa.find(s => s.id === j.siswaId);
      const nama = siswa ? siswa.nama : '';
      return (j.catatan + (j.topik || '') + nama).toLowerCase().includes(q);
    });
  }

  renderList('listJurnal', data, 'Belum ada jurnal. Mulai tulis observasi siswa.', j => {
    const siswa = state.siswa.find(s => s.id === j.siswaId);
    const nama = siswa ? siswa.nama : 'Siswa dihapus';
    const nilaiBadge = j.nilai ? `<span class="badge ${nilaiClass(j.nilai)}">${j.nilai}</span>` : '';
    return `
      <div class="list-item">
        <div>
          <div class="meta">${formatDate(j.tanggal)} · ${escapeHtml(nama)} · ${escapeHtml(j.mood || '')}</div>
          <div class="title">${escapeHtml(j.topik || 'Tanpa topik')} ${nilaiBadge}</div>
          <div class="desc">${escapeHtml(j.catatan)}</div>
        </div>
        <div class="actions">
          <button class="btn-danger" onclick="hapusJurnal('${j.id}')">Hapus</button>
        </div>
      </div>
    `;
  });
}

function simpanJurnal(e) {
  e.preventDefault();
  const tanggal = document.getElementById('jurnalTanggal').value;
  const siswaId = document.getElementById('jurnalSiswa').value;
  const topik = document.getElementById('jurnalTopik').value.trim();
  const catatan = document.getElementById('jurnalCatatan').value.trim();
  const nilai = document.getElementById('jurnalNilai').value;
  const mood = document.getElementById('jurnalMood').value;

  if (!tanggal || !siswaId || !catatan) return;

  state.jurnal.push({
    id: uid(),
    tanggal,
    siswaId,
    topik,
    catatan,
    nilai,
    mood,
    createdAt: new Date().toISOString()
  });
  save(STORAGE_KEYS.jurnal, state.jurnal);
  document.getElementById('formJurnal').reset();
  document.getElementById('jurnalTanggal').value = today();
  renderJurnal();
  alert('Jurnal berhasil disimpan!');
}

function hapusJurnal(id) {
  if (!confirm('Hapus jurnal ini?')) return;
  state.jurnal = state.jurnal.filter(j => j.id !== id);
  save(STORAGE_KEYS.jurnal, state.jurnal);
  renderJurnal();
}

/* ===== KEGIATAN ===== */
function renderKegiatan() {
  const data = [...state.kegiatan].sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  renderList('listKegiatan', data, 'Belum ada kegiatan tercatat.', k => `
    <div class="list-item">
      <div>
        <div class="meta">${formatDate(k.tanggal)} · ${escapeHtml(k.jenis)}</div>
        <div class="title">${escapeHtml(k.judul)}</div>
        <div class="desc">${escapeHtml(k.detail || '')}</div>
      </div>
      <div class="actions">
        <button class="btn-danger" onclick="hapusKegiatan('${k.id}')">Hapus</button>
      </div>
    </div>
  `);
}

function simpanKegiatan(e) {
  e.preventDefault();
  const tanggal = document.getElementById('kegiatanTanggal').value;
  const jenis = document.getElementById('kegiatanJenis').value;
  const judul = document.getElementById('kegiatanJudul').value.trim();
  const detail = document.getElementById('kegiatanDetail').value.trim();

  if (!tanggal || !judul) return;

  state.kegiatan.push({ id: uid(), tanggal, jenis, judul, detail });
  save(STORAGE_KEYS.kegiatan, state.kegiatan);
  document.getElementById('formKegiatan').reset();
  document.getElementById('kegiatanTanggal').value = today();
  renderKegiatan();
}

function hapusKegiatan(id) {
  if (!confirm('Hapus kegiatan ini?')) return;
  state.kegiatan = state.kegiatan.filter(k => k.id !== id);
  save(STORAGE_KEYS.kegiatan, state.kegiatan);
  renderKegiatan();
}

/* ===== DASHBOARD ===== */
function updateDashboard() {
  const tdy = today();
  const jurnalHariIni = state.jurnal.filter(j => j.tanggal === tdy).length;

  const elJ = document.getElementById('statJurnal');
  const elS = document.getElementById('statSiswa');
  const elK = document.getElementById('statKegiatan');
  const elJT = document.getElementById('statJurnalTotal');
  if (elJ) elJ.textContent = jurnalHariIni;
  if (elS) elS.textContent = state.siswa.length;
  if (elK) elK.textContent = state.kegiatan.length;
  if (elJT) elJT.textContent = state.jurnal.length;

  // --- kinerja guru ---
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const weekStart = new Date(now);
  weekStart.setDate(weekStart.getDate() - 6);
  const monthStart = new Date(now);
  monthStart.setDate(monthStart.getDate() - 29);

  const parseD = (d) => {
    if (!d) return null;
    const [y, m, day] = d.split('-').map(Number);
    return new Date(y, m - 1, day);
  };

  const jurnalMinggu = state.jurnal.filter(j => {
    const d = parseD(j.tanggal);
    return d && d >= weekStart && d <= now;
  });
  const jurnalBulan = state.jurnal.filter(j => {
    const d = parseD(j.tanggal);
    return d && d >= monthStart && d <= now;
  });

  const siswaCoverSet = new Set(state.jurnal.map(j => j.siswaId).filter(Boolean));
  const daysWithJurnal = new Set(jurnalBulan.map(j => j.tanggal));
  const konsistensi = Math.round((daysWithJurnal.size / 30) * 100);

  const elMJ = document.getElementById('statMingguJurnal');
  const elBJ = document.getElementById('statBulanJurnal');
  const elSC = document.getElementById('statSiswaCover');
  const elKo = document.getElementById('statKonsistensi');
  if (elMJ) elMJ.textContent = jurnalMinggu.length;
  if (elBJ) elBJ.textContent = jurnalBulan.length;
  if (elSC) elSC.textContent = siswaCoverSet.size;
  if (elKo) elKo.textContent = state.jurnal.length ? (konsistensi + '%') : '—';

  // capaian kelas dari progres siswa
  let totalXP = 0, kog = [], non = [];
  if (typeof hitungSemuaProgres === 'function') {
    const all = hitungSemuaProgres();
    all.forEach(s => {
      totalXP += s.progres.totalXP || 0;
      if (s.progres.kognitif != null) kog.push(s.progres.kognitif);
      if (s.progres.nonkognitif != null) non.push(s.progres.nonkognitif);
    });
  }
  const avg = arr => arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null;
  const avgK = avg(kog);
  const avgN = avg(non);
  const elKog = document.getElementById('dashKog');
  const elNon = document.getElementById('dashNon');
  const elXP = document.getElementById('dashXP');
  if (elKog) elKog.textContent = avgK != null ? avgK : '—';
  if (elNon) elNon.textContent = avgN != null ? avgN : '—';
  if (elXP) elXP.textContent = totalXP;

  // ringkasan kinerja teks
  const kinerjaBox = document.getElementById('kinerjaBox');
  if (kinerjaBox) {
    const coverage = state.siswa.length
      ? Math.round((siswaCoverSet.size / state.siswa.length) * 100)
      : 0;
    let predikat = 'Perlu ditingkatkan';
    if (jurnalBulan.length >= 20 && konsistensi >= 50) predikat = 'Sangat baik';
    else if (jurnalBulan.length >= 10 && konsistensi >= 30) predikat = 'Baik';
    else if (jurnalBulan.length >= 5) predikat = 'Cukup';

    kinerjaBox.innerHTML = `
      <div class="list-item"><div>
        <div class="title">Predikat kinerja bulan ini</div>
        <div class="desc"><span class="badge ${predikat === 'Sangat baik' || predikat === 'Baik' ? 'success' : predikat === 'Cukup' ? 'warning' : 'danger'}">${predikat}</span></div>
      </div></div>
      <div class="list-item"><div>
        <div class="title">Cakupan observasi siswa</div>
        <div class="desc">${siswaCoverSet.size} dari ${state.siswa.length} siswa (${coverage}%)</div>
      </div></div>
      <div class="list-item"><div>
        <div class="title">Aktivitas jurnal 7 hari terakhir</div>
        <div class="desc">${jurnalMinggu.length} catatan observasi</div>
      </div></div>
      <div class="list-item"><div>
        <div class="title">Kegiatan tercatat bulan ini</div>
        <div class="desc">${state.kegiatan.filter(k => {
          const d = parseD(k.tanggal);
          return d && d >= monthStart && d <= now;
        }).length} kegiatan</div>
      </div></div>
    `;
  }

  const note = document.getElementById('kinerjaNote');
  if (note) {
    if (!state.jurnal.length) {
      note.textContent = 'Belum ada jurnal. Mulai catat observasi siswa agar kinerja dapat diukur.';
    } else {
      note.textContent = 'Indeks konsistensi = persentase hari dengan minimal 1 jurnal dalam 30 hari terakhir. Semakin rutin menulis jurnal, semakin tinggi indeks kinerja.';
    }
  }

  // recent jurnal
  const recentJ = [...state.jurnal].sort((a, b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 5);
  renderList('recentJurnal', recentJ, 'Belum ada jurnal.', j => {
    const siswa = state.siswa.find(s => s.id === j.siswaId);
    return `
      <div class="list-item">
        <div>
          <div class="meta">${formatDate(j.tanggal)} · ${siswa ? escapeHtml(siswa.nama) : '-'}</div>
          <div class="title">${escapeHtml(j.topik || 'Observasi')}</div>
          <div class="desc">${escapeHtml(j.catatan.slice(0, 80))}${j.catatan.length > 80 ? '...' : ''}</div>
        </div>
      </div>
    `;
  });

  // recent kegiatan
  const recentK = [...state.kegiatan].sort((a, b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 5);
  renderList('recentKegiatan', recentK, 'Belum ada kegiatan.', k => `
    <div class="list-item">
      <div>
        <div class="meta">${formatDate(k.tanggal)} · ${escapeHtml(k.jenis)}</div>
        <div class="title">${escapeHtml(k.judul)}</div>
      </div>
    </div>
  `);
}

/* ===== INIT PER PAGE ===== */
document.addEventListener('DOMContentLoaded', async () => {
  // Guard: halaman guru wajib login sebagai guru
  // (login.html & wali/ tidak memakai requireGuru ini)
  if (!document.body.dataset.noAuth) {
    if (!(await requireGuru())) return;
  }

  await loadState();
  initParallax();

  // tampilkan nama + logout
  const auth = getAuth();
  const teacherEl = document.getElementById('teacherName');
  if (teacherEl && auth) {
    const nm = auth.name || auth.email || 'Guru';
    teacherEl.textContent = nm;
    teacherEl.title = auth.email || '';
    document.querySelectorAll('.sidebar .avatar, #profileAvatar').forEach(av => {
      av.textContent = (nm[0] || 'G').toUpperCase();
    });
  }
  try { if (typeof applyProfileMedia === "function") applyProfileMedia(); } catch (e) { console.warn(e); }

  // set tanggal default
  const jTanggal = document.getElementById('jurnalTanggal');
  if (jTanggal) jTanggal.value = today();
  const kTanggal = document.getElementById('kegiatanTanggal');
  if (kTanggal) kTanggal.value = today();
  const gDate = document.getElementById('globalDate');
  if (gDate) gDate.value = today();

  // page-specific
  if (document.getElementById('listSiswa') || document.getElementById('jurnalSiswa')) {
    renderSiswa();
    const searchSiswa = document.getElementById('searchSiswa');
    if (searchSiswa) {
      searchSiswa.addEventListener('input', e => renderSiswa(e.target.value));
    }
  }
  if (document.getElementById('listJurnal')) {
    renderJurnal();
    const search = document.getElementById('searchJurnal');
    if (search) search.addEventListener('input', e => renderJurnal(e.target.value));
  }
  if (document.getElementById('listKegiatan')) {
    renderKegiatan();
  }
  if (document.getElementById('recentJurnal') || document.getElementById('statJurnal')) {
    try { updateDashboard(); } catch (e) { console.warn('dashboard', e); }
  }

  // Analisa charts kegiatan
  if (document.getElementById('chartMinggu')) {
    initAnalisaCharts();
  }

  // Analisa nilai / XP
  if (document.getElementById('chartLevel') || document.getElementById('statKog')) {
    initNilaiAnalisa();
  }

  // Halaman Nilai & XP
  if (document.getElementById('listNilaiProgres')) {
    fillNilaiSelect();
    renderNilaiProgres();
    const sn = document.getElementById('searchNilai');
    if (sn) sn.addEventListener('input', e => renderNilaiProgres(e.target.value));
    const nt = document.getElementById('nilaiTanggal');
    if (nt) nt.value = today();
    const fn = document.getElementById('formNilai');
    if (fn) fn.addEventListener('submit', simpanNilai);
    const btnH = document.getElementById('btnHitungSemua');
    if (btnH) btnH.addEventListener('click', () => {
      renderNilaiProgres(document.getElementById('searchNilai')?.value || '');
      alert('Progres dihitung ulang dari jurnal + nilai + kegiatan.');
    });
  }

  // forms
  const formSiswa = document.getElementById('formSiswa');
  if (formSiswa) formSiswa.addEventListener('submit', tambahSiswa);

  const formJurnal = document.getElementById('formJurnal');
  if (formJurnal) formJurnal.addEventListener('submit', simpanJurnal);

  const formKegiatan = document.getElementById('formKegiatan');
  if (formKegiatan) formKegiatan.addEventListener('submit', simpanKegiatan);
});

// expose for onclick
window.hapusSiswa = hapusSiswa;
window.hapusJurnal = hapusJurnal;
window.hapusKegiatan = hapusKegiatan;





/* ===== PROFILE PHOTO & BACKGROUND ===== */
const PROFILE_KEY = 'jg_profile_media';

/* IndexedDB untuk background video besar (hingga 150 MB) */
const IDB_NAME = 'smart_jurnal_media';
const IDB_STORE = 'files';

function openMediaDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbSet(key, value) {
  const db = await openMediaDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function idbGet(key) {
  const db = await openMediaDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readonly');
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbDel(key) {
  const db = await openMediaDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}


function getProfileMedia() {
  try {
    return JSON.parse(localStorage.getItem(PROFILE_KEY)) || {};
  } catch {
    return {};
  }
}

function saveProfileMedia(data) {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(data));
}

function ensureBgVideoEl() {
  let v = document.getElementById('jg-bg-video');
  if (!v) {
    v = document.createElement('video');
    v.id = 'jg-bg-video';
    v.muted = true;
    v.loop = true;
    v.autoplay = true;
    v.playsInline = true;
    v.setAttribute('playsinline', '');
    Object.assign(v.style, {
      position: 'fixed',
      inset: '0',
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      zIndex: '0',
      pointerEvents: 'none'
    });
    document.body.prepend(v);
  }
  return v;
}

function clearBgMedia() {
  document.body.style.backgroundImage = '';
  document.body.style.backgroundSize = '';
  document.body.style.backgroundPosition = '';
  document.body.style.backgroundAttachment = '';
  const v = document.getElementById('jg-bg-video');
  if (v) {
    v.pause();
    v.removeAttribute('src');
    v.load();
    v.style.display = 'none';
  }
}

function applyProfileMedia() {
  const media = getProfileMedia();
  // avatar images
  if (media.avatar) {
    document.querySelectorAll('.sidebar .avatar, #profileAvatar, #profilePageAvatar').forEach(el => {
      el.style.backgroundImage = `url(${media.avatar})`;
      el.style.backgroundSize = 'cover';
      el.style.backgroundPosition = 'center';
      el.textContent = '';
    });
  }
  // background: photo or video
  if (media.bgType === 'video') {
    document.body.style.backgroundImage = '';
    (async () => {
      try {
        const blob = await idbGet('bg_video');
        if (!blob) return;
        const v = ensureBgVideoEl();
        v.style.display = 'block';
        const url = URL.createObjectURL(blob);
        if (v.dataset.objectUrl) URL.revokeObjectURL(v.dataset.objectUrl);
        v.dataset.objectUrl = url;
        v.src = url;
        v.play().catch(() => {});
      } catch (e) {
        console.warn('Gagal load bg video', e);
      }
    })();
  } else if (media.bg) {
    const v = document.getElementById('jg-bg-video');
    if (v) {
      v.pause();
      v.style.display = 'none';
    }
    document.body.style.backgroundImage = `url(${media.bg})`;
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center';
    document.body.style.backgroundAttachment = 'fixed';
  }
}

function readFileAsDataURL(file, maxSide = 800) {
  return new Promise((resolve, reject) => {
    if (!file) {
      reject(new Error('Tidak ada file'));
      return;
    }
    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');
    if (!isImage && !isVideo) {
      reject(new Error('File harus gambar atau video'));
      return;
    }
    // video lebih besar; batasi agar localStorage tidak penuh
    const maxBytes = isVideo ? 150 * 1024 * 1024 : 2.5 * 1024 * 1024;
    if (file.size > maxBytes) {
      reject(new Error(isVideo ? 'Video max 150 MB' : 'Gambar max 2.5 MB'));
      return;
    }
    if (isVideo) {
      // simpan sebagai Blob (bukan dataURL) agar muat hingga 150 MB via IndexedDB
      resolve({ blob: file, type: 'video', mime: file.type });
      return;
    }
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let { width, height } = img;
      const scale = Math.min(1, maxSide / Math.max(width, height));
      width = Math.round(width * scale);
      height = Math.round(height * scale);
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);
      resolve({ dataUrl: canvas.toDataURL('image/jpeg', 0.85), type: 'image' });
    };
    img.onerror = () => reject(new Error('Gagal membaca gambar'));
    img.src = url;
  });
}


/* ===== ANALISA CHART ===== */
function parseDate(d) {
  if (!d) return null;
  const [y, m, day] = d.split('-').map(Number);
  return new Date(y, m - 1, day);
}

function daysAgo(n) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - n);
  return d;
}

function toKey(dateObj) {
  const y = dateObj.getFullYear();
  const m = String(dateObj.getMonth() + 1).padStart(2, '0');
  const day = String(dateObj.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function labelDay(dateObj) {
  const names = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
  return names[dateObj.getDay()] + ' ' + dateObj.getDate();
}

function initAnalisaCharts() {
  if (typeof Chart === 'undefined') return;
  if (!document.getElementById('chartMinggu')) return;

  const kegiatan = state.kegiatan || [];
  const now = new Date();
  now.setHours(0, 0, 0, 0);

  const weekStart = daysAgo(6);
  const monthStart = daysAgo(29);

  const mingguItems = kegiatan.filter(k => {
    const d = parseDate(k.tanggal);
    return d && d >= weekStart && d <= now;
  });
  const bulanItems = kegiatan.filter(k => {
    const d = parseDate(k.tanggal);
    return d && d >= monthStart && d <= now;
  });

  const elM = document.getElementById('statMinggu');
  const elB = document.getElementById('statBulan');
  const elT = document.getElementById('statTotal');
  if (elM) elM.textContent = mingguItems.length;
  if (elB) elB.textContent = bulanItems.length;
  if (elT) elT.textContent = kegiatan.length;

  // Daily counts last 7 days
  const labels7 = [];
  const data7 = [];
  for (let i = 6; i >= 0; i--) {
    const d = daysAgo(i);
    const key = toKey(d);
    labels7.push(labelDay(d));
    data7.push(kegiatan.filter(k => k.tanggal === key).length);
  }

  // Daily counts last 30 days (group by day still, or simplified bar)
  const labels30 = [];
  const data30 = [];
  for (let i = 29; i >= 0; i--) {
    const d = daysAgo(i);
    labels30.push(d.getDate() + '/' + (d.getMonth() + 1));
    data30.push(kegiatan.filter(k => k.tanggal === toKey(d)).length);
  }

  // Jenis breakdown bulan ini
  const jenisMap = {};
  bulanItems.forEach(k => {
    const j = k.jenis || 'Lainnya';
    jenisMap[j] = (jenisMap[j] || 0) + 1;
  });
  const jenisLabels = Object.keys(jenisMap);
  const jenisData = Object.values(jenisMap);

  const blue = '#2563eb';
  const cyan = '#0ea5e9';
  const colors = ['#2563eb', '#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444'];

  new Chart(document.getElementById('chartMinggu'), {
    type: 'bar',
    data: {
      labels: labels7,
      datasets: [{
        label: 'Jumlah kegiatan',
        data: data7,
        backgroundColor: 'rgba(37, 99, 235, 0.75)',
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: '#f3f4f6' } },
        x: { grid: { display: false } }
      }
    }
  });

  new Chart(document.getElementById('chartBulan'), {
    type: 'line',
    data: {
      labels: labels30,
      datasets: [{
        label: 'Kegiatan',
        data: data30,
        borderColor: cyan,
        backgroundColor: 'rgba(14, 165, 233, 0.12)',
        fill: true,
        tension: 0.35,
        pointRadius: 2,
        pointHoverRadius: 5
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: '#f3f4f6' } },
        x: {
          grid: { display: false },
          ticks: { maxTicksLimit: 10, maxRotation: 0 }
        }
      }
    }
  });

  if (jenisLabels.length) {
    new Chart(document.getElementById('chartJenis'), {
      type: 'doughnut',
      data: {
        labels: jenisLabels,
        datasets: [{
          data: jenisData,
          backgroundColor: colors.slice(0, jenisLabels.length),
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, padding: 14 } }
        }
      }
    });
  } else {
    const canvas = document.getElementById('chartJenis');
    if (canvas && canvas.parentElement) {
      canvas.parentElement.innerHTML = '<div class="empty">Belum ada kegiatan bulan ini.</div>';
    }
  }
}


/* =========================================================
   NILAI · XP · KOGNITIF · NON-KOGNITIF
   Algoritma profesional bergaya progression (XP game)
   ========================================================= */

const NILAI_MAP = {
  'Sangat Baik': 95,
  'Baik': 80,
  'Cukup': 65,
  'Perlu Perhatian': 45
};

const MOOD_NONKOG = {
  'Semangat': 90,
  'Tenang': 80,
  'Netral': 70,
  'Lesu': 50,
  'Tegang': 45
};

// Kata kunci klasifikasi topik jurnal
const KOG_KEYWORDS = ['prestasi','nilai','tugas','ulangan','ujian','pemahaman','materi','skill','keterampilan','akademik','kognitif','jawab','soal','proyek','presentasi'];
const NON_KEYWORDS = ['sikap','karakter','disiplin','sopan','kerjasama','tanggung','jujur','empati','mood','perilaku','aktif','partisipasi','kehadiran','non'];

function klasifikasiTopik(topik, catatan) {
  const t = ((topik || '') + ' ' + (catatan || '')).toLowerCase();
  let kog = 0, non = 0;
  KOG_KEYWORDS.forEach(k => { if (t.includes(k)) kog++; });
  NON_KEYWORDS.forEach(k => { if (t.includes(k)) non++; });
  if (kog === 0 && non === 0) return { kog: 0.55, non: 0.45 }; // default seimbang
  const total = kog + non;
  return { kog: kog / total, non: non / total };
}

/** XP dari satu jurnal */
function xpDariJurnal(j) {
  const base = NILAI_MAP[j.nilai] || 55;
  const moodBonus = (MOOD_NONKOG[j.mood] || 70) / 100 * 15; // max +15
  return Math.round(base + moodBonus);
}

/** Kontribusi skor kognitif & non-kognitif dari jurnal (0-100) */
function skorDariJurnal(j) {
  const base = NILAI_MAP[j.nilai] || 60;
  const weight = klasifikasiTopik(j.topik, j.catatan);
  const mood = MOOD_NONKOG[j.mood] || 70;
  const kognitif = Math.round(base * weight.kog + 50 * (1 - weight.kog) * 0.3);
  const nonkognitif = Math.round(mood * weight.non + base * (1 - weight.non) * 0.4);
  return {
    kognitif: clamp(kognitif, 0, 100),
    nonkognitif: clamp(nonkognitif, 0, 100)
  };
}

/** XP dari kegiatan (lebih kecil, reward partisipasi) */
function xpDariKegiatan(k) {
  const map = {
    'Pembelajaran': 25,
    'Ekstrakurikuler': 30,
    'Rapat': 10,
    'Administrasi': 8,
    'Lainnya': 12
  };
  return map[k.jenis] || 12;
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

/** Level dari total XP — kurva mirip RPG (lambat di awal, stabil) */
function levelDariXP(xp) {
  // Level 1: 0-99, Level 2: 100-249, Level 3: 250-449, ...
  // formula: level = floor( (sqrt(100 + 80*xp) - 10) / 20 ) + 1  simplified:
  let level = 1;
  let need = 100;
  let remain = xp;
  while (remain >= need) {
    remain -= need;
    level++;
    need = Math.round(100 + level * 40);
  }
  const progress = need > 0 ? remain / need : 0;
  return { level, progress, nextNeed: need, remainInLevel: remain };
}

/**
 * Hitung profil progres 1 siswa
 * Sumber: jurnal + kegiatan (semua, proporsi) + nilai manual
 */
function hitungProgresSiswa(siswaId) {
  const jurnals = state.jurnal.filter(j => j.siswaId === siswaId);
  const manual = state.nilai.filter(n => n.siswaId === siswaId);
  // kegiatan bersifat kelas — bagi XP kecil ke semua siswa (opsional)
  // di sini: kegiatan tidak auto ke siswa kecuali ada mapping; hanya jurnal + manual

  let totalXP = 0;
  let kogList = [];
  let nonList = [];

  jurnals.forEach(j => {
    totalXP += xpDariJurnal(j);
    const s = skorDariJurnal(j);
    kogList.push(s.kognitif);
    nonList.push(s.nonkognitif);
  });

  manual.forEach(n => {
    const skor = Number(n.skor) || 0;
    // XP manual: skor * 0.9
    totalXP += Math.round(skor * 0.9);
    if (n.aspek === 'kognitif') kogList.push(skor);
    else nonList.push(skor);
  });

  // Bonus partisipasi kegiatan (flat kecil berdasarkan jumlah kegiatan bulan ini)
  const now = new Date();
  const bulanItems = (state.kegiatan || []).filter(k => {
    if (!k.tanggal) return false;
    const [y, m] = k.tanggal.split('-').map(Number);
    return y === now.getFullYear() && m === (now.getMonth() + 1);
  });
  const kegiatanBonus = Math.min(bulanItems.length * 5, 50); // max +50 XP
  totalXP += kegiatanBonus;

  const avg = arr => arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null;

  const levelInfo = levelDariXP(totalXP);

  return {
    totalXP,
    level: levelInfo.level,
    progress: levelInfo.progress,
    nextNeed: levelInfo.nextNeed,
    kognitif: avg(kogList),
    nonkognitif: avg(nonList),
    jurnalCount: jurnals.length,
    manualCount: manual.length
  };
}

function hitungSemuaProgres() {
  return state.siswa.map(s => ({
    ...s,
    progres: hitungProgresSiswa(s.id)
  })).sort((a, b) => b.progres.totalXP - a.progres.totalXP);
}

/* ===== RENDER NILAI PAGE ===== */
function renderNilaiProgres(filter = '') {
  const el = document.getElementById('listNilaiProgres');
  if (!el) return;

  let data = hitungSemuaProgres();
  if (filter) {
    const q = filter.toLowerCase();
    data = data.filter(s =>
      (s.nama || '').toLowerCase().includes(q) ||
      (s.kelas || '').toLowerCase().includes(q) ||
      (s.nik || '').toLowerCase().includes(q)
    );
  }

  if (!data.length) {
    el.innerHTML = '<div class="empty">Belum ada siswa / data progres.</div>';
    return;
  }

  el.innerHTML = data.map(s => {
    const p = s.progres;
    const pct = Math.round((p.progress || 0) * 100);
    const kog = p.kognitif != null ? p.kognitif : '—';
    const non = p.nonkognitif != null ? p.nonkognitif : '—';
    return `
      <div class="list-item" style="flex-direction:column;align-items:stretch;gap:10px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
          <div>
            <div class="title">${escapeHtml(s.nama)} <span class="level-badge">Tahap ${p.level}</span></div>
            <div class="meta">Kelas ${escapeHtml(s.kelas)} · ${p.jurnalCount} jurnal · ${p.manualCount} nilai manual</div>
          </div>
          <div style="text-align:right;font-size:13px;font-weight:600;color:#0ea5e9;">${p.totalXP} poin</div>
        </div>
        <div>
          <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-muted);margin-bottom:4px;">
            <span>Menuju tahap capaian berikutnya</span>
            <span>${pct}%</span>
          </div>
          <div class="xp-bar-wrap"><div class="xp-bar" style="width:${pct}%"></div></div>
        </div>
        <div class="score-grid">
          <div class="score-box kog"><div class="lbl">Kognitif</div><div class="val">${kog}</div></div>
          <div class="score-box non"><div class="lbl">Non-kognitif</div><div class="val">${non}</div></div>
          <div class="score-box xp"><div class="lbl">Poin Progres</div><div class="val">${p.totalXP}</div></div>
        </div>
      </div>
    `;
  }).join('');
}

function fillNilaiSelect() {
  const select = document.getElementById('nilaiSiswa');
  if (!select) return;
  select.innerHTML = '<option value="">-- Pilih Siswa --</option>' +
    state.siswa.map(s => `<option value="${s.id}">${escapeHtml(s.nama)} (${escapeHtml(s.kelas)})</option>`).join('');
}

function simpanNilai(e) {
  e.preventDefault();
  const siswaId = document.getElementById('nilaiSiswa').value;
  const tanggal = document.getElementById('nilaiTanggal').value;
  const aspek = document.getElementById('nilaiAspek').value;
  const skor = Number(document.getElementById('nilaiSkor').value);
  const catatan = document.getElementById('nilaiCatatan').value.trim();
  if (!siswaId || !tanggal || isNaN(skor)) return;
  if (skor < 0 || skor > 100) {
    alert('Skor harus 0–100');
    return;
  }

  state.nilai.push({
    id: uid(),
    siswaId,
    tanggal,
    aspek,
    skor,
    catatan,
    createdAt: new Date().toISOString()
  });
  save(STORAGE_KEYS.nilai, state.nilai);
  document.getElementById('formNilai').reset();
  document.getElementById('nilaiTanggal').value = today();
  renderNilaiProgres();
  alert('Nilai disimpan. Progres siswa diperbarui.');
}

/* ===== ANALISA: extend charts nilai ===== */
function initNilaiAnalisa() {
  if (typeof Chart === 'undefined') return;
  if (!document.getElementById('chartLevel') && !document.getElementById('statKog')) return;

  const all = hitungSemuaProgres();

  const kogVals = all.map(s => s.progres.kognitif).filter(v => v != null);
  const nonVals = all.map(s => s.progres.nonkognitif).filter(v => v != null);
  const totalXP = all.reduce((a, s) => a + s.progres.totalXP, 0);
  const avg = arr => arr.length ? Math.round(arr.reduce((x, y) => x + y, 0) / arr.length) : null;

  const elK = document.getElementById('statKog');
  const elN = document.getElementById('statNon');
  const elX = document.getElementById('statXP');
  if (elK) elK.textContent = avg(kogVals) != null ? avg(kogVals) : '—';
  if (elN) elN.textContent = avg(nonVals) != null ? avg(nonVals) : '—';
  if (elX) elX.textContent = totalXP;

  // Level distribution
  if (document.getElementById('chartLevel')) {
    const levelCount = {};
    all.forEach(s => {
      const lv = 'Tahap ' + s.progres.level;
      levelCount[lv] = (levelCount[lv] || 0) + 1;
    });
    const labels = Object.keys(levelCount).sort();
    const data = labels.map(l => levelCount[l]);

    if (labels.length) {
      new Chart(document.getElementById('chartLevel'), {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Jumlah siswa',
            data,
            backgroundColor: 'rgba(37,99,235,0.75)',
            borderRadius: 8,
            borderSkipped: false
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: '#f3f4f6' } },
            x: { grid: { display: false } }
          }
        }
      });
    } else {
      document.getElementById('chartLevel').parentElement.innerHTML = '<div class="empty">Belum ada data tahap capaian.</div>';
    }
  }

  // Kog vs Non average bar
  if (document.getElementById('chartRadar')) {
    const ak = avg(kogVals) || 0;
    const an = avg(nonVals) || 0;
    new Chart(document.getElementById('chartRadar'), {
      type: 'bar',
      data: {
        labels: ['Kognitif', 'Non-kognitif'],
        datasets: [{
          data: [ak, an],
          backgroundColor: ['rgba(37,99,235,0.8)', 'rgba(139,92,246,0.8)'],
          borderRadius: 10,
          borderSkipped: false
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, max: 100, grid: { color: '#f3f4f6' } },
          y: { grid: { display: false } }
        }
      }
    });
  }

  // Ranking list
  const rankEl = document.getElementById('listRanking');
  if (rankEl) {
    if (!all.length) {
      rankEl.innerHTML = '<div class="empty">Belum ada ranking.</div>';
    } else {
      rankEl.innerHTML = all.slice(0, 10).map((s, i) => `
        <div class="list-item">
          <div>
            <div class="meta">#${i + 1} · Tahap ${s.progres.level}</div>
            <div class="title">${escapeHtml(s.nama)} <span class="badge">${s.progres.totalXP} poin</span></div>
            <div class="desc">Kognitif: ${s.progres.kognitif ?? '—'} · Non-kognitif: ${s.progres.nonkognitif ?? '—'}</div>
          </div>
        </div>
      `).join('');
    }
  }
}

