/* Smart Jurnal — Supabase client */
const SUPABASE_URL = "https://yjlznqzgtlggzrzdwvuj.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_1CgIy1SKcbU_wF9EmbdYug_Xk6M1uzp";
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
});
window.sb = sb;

async function getSessionUser() {
  const { data: { session } } = await sb.auth.getSession();
  return session?.user || null;
}

async function requireAuth(roles = []) {
  const user = await getSessionUser();
  if (!user) {
    location.replace(new URL('../login.html', location.href).href);
    return null;
  }
  const { data: profile, error } = await sb.from('profiles').select('id,email,name,role,status').eq('id', user.id).single();
  if (error || !profile || profile.status !== 'active' || (roles.length && !roles.includes(profile.role))) {
    await sb.auth.signOut();
    alert('Akun tidak memiliki akses atau sedang diblokir.');
    location.replace(new URL('../login.html', location.href).href);
    return null;
  }
  return { user, profile };
}

window.SmartJurnalAuth = { getSessionUser, requireAuth };
