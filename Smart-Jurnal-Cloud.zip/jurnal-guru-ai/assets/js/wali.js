
function getWaliAuth(){return {role:'wali'}}
async function requireWali(){const raw=sessionStorage.getItem('jg_wali_cloud');if(!raw){location.href='../login.html';return null;}return {role:'wali'};}
async function logout(){sessionStorage.removeItem('jg_wali_cloud');location.replace('../login.html');}
const KEYS={siswa:'siswa',jurnal:'jurnal',kegiatan:'kegiatan',nilai:'nilai'};
let cloudCache=[];
async function loadCloud(){try{const d=JSON.parse(sessionStorage.getItem('jg_wali_cloud')||'null');if(!d?.ok)return [];return [{kind:'siswa',data:d.student,record_id:d.student.id},...(d.jurnal||[]).map(x=>({kind:'jurnal',data:x,record_id:x.id})),...(d.nilai||[]).map(x=>({kind:'nilai',data:x,record_id:x.id})),...(d.kegiatan||[]).map(x=>({kind:'kegiatan',data:x,record_id:x.id}))];}catch{return [];}}
function load(key){ const kind=Object.entries(KEYS).find(([,v])=>v===key)?.[0]||key; return cloudCache.filter(r=>r.kind===kind).map(r=>({...r.data,id:r.record_id})); }

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDate(d) {
  if (!d) return '-';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function nilaiBadge(n) {
  if (!n) return '';
  let cls = 'danger';
  if (n === 'Sangat Baik' || n === 'Baik') cls = 'success';
  else if (n === 'Cukup') cls = 'warning';
  return `<span class="badge ${cls}">${escapeHtml(n)}</span>`;
}

/* --- Algoritma XP (mirror dari script guru) --- */
const NILAI_MAP = { 'Sangat Baik': 95, 'Baik': 80, 'Cukup': 65, 'Perlu Perhatian': 45 };
const MOOD_NONKOG = { 'Semangat': 90, 'Tenang': 80, 'Netral': 70, 'Lesu': 50, 'Tegang': 45 };
const KOG_KEYWORDS = ['prestasi','nilai','tugas','ulangan','ujian','pemahaman','materi','skill','keterampilan','akademik','kognitif','jawab','soal','proyek','presentasi'];
const NON_KEYWORDS = ['sikap','karakter','disiplin','sopan','kerjasama','tanggung','jujur','empati','mood','perilaku','aktif','partisipasi','kehadiran','non'];

function klasifikasiTopik(topik, catatan) {
  const t = ((topik || '') + ' ' + (catatan || '')).toLowerCase();
  let kog = 0, non = 0;
  KOG_KEYWORDS.forEach(k => { if (t.includes(k)) kog++; });
  NON_KEYWORDS.forEach(k => { if (t.includes(k)) non++; });
  if (kog === 0 && non === 0) return { kog: 0.55, non: 0.45 };
  const total = kog + non;
  return { kog: kog / total, non: non / total };
}

function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }

function skorDariJurnal(j) {
  const base = NILAI_MAP[j.nilai] || 60;
  const weight = klasifikasiTopik(j.topik, j.catatan);
  const mood = MOOD_NONKOG[j.mood] || 70;
  const kognitif = Math.round(base * weight.kog + 50 * (1 - weight.kog) * 0.3);
  const nonkognitif = Math.round(mood * weight.non + base * (1 - weight.non) * 0.4);
  return { kognitif: clamp(kognitif, 0, 100), nonkognitif: clamp(nonkognitif, 0, 100) };
}

function xpDariJurnal(j) {
  const base = NILAI_MAP[j.nilai] || 55;
  const moodBonus = (MOOD_NONKOG[j.mood] || 70) / 100 * 15;
  return Math.round(base + moodBonus);
}

function levelDariXP(xp) {
  let level = 1, need = 100, remain = xp;
  while (remain >= need) {
    remain -= need;
    level++;
    need = Math.round(100 + level * 40);
  }
  return { level, progress: need > 0 ? remain / need : 0, nextNeed: need };
}

function hitungProgres(siswaId) {
  const jurnals = load(KEYS.jurnal).filter(j => j.siswaId === siswaId);
  const manual = load(KEYS.nilai).filter(n => n.siswaId === siswaId);
  let totalXP = 0, kogList = [], nonList = [];

  jurnals.forEach(j => {
    totalXP += xpDariJurnal(j);
    const s = skorDariJurnal(j);
    kogList.push(s.kognitif);
    nonList.push(s.nonkognitif);
  });
  manual.forEach(n => {
    const skor = Number(n.skor) || 0;
    totalXP += Math.round(skor * 0.9);
    if (n.aspek === 'kognitif') kogList.push(skor);
    else nonList.push(skor);
  });

  const now = new Date();
  const bulanItems = load(KEYS.kegiatan).filter(k => {
    if (!k.tanggal) return false;
    const [y, m] = k.tanggal.split('-').map(Number);
    return y === now.getFullYear() && m === (now.getMonth() + 1);
  });
  totalXP += Math.min(bulanItems.length * 5, 50);

  const avg = arr => arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : null;
  const lv = levelDariXP(totalXP);
  return {
    totalXP,
    level: lv.level,
    progress: lv.progress,
    kognitif: avg(kogList),
    nonkognitif: avg(nonList)
  };
}

function cari() {
  const q = (document.getElementById('cariInput').value || '').trim().toLowerCase();
  const box = document.getElementById('hasilCari');
  if (!q) {
    box.innerHTML = '<div class="empty">Ketik nama atau NIK lalu klik Cari.</div>';
    return;
  }
  const found = load(KEYS.siswa).filter(s => {
    const nama = (s.nama || '').toLowerCase();
    return nama.includes(q);
  });
  if (!found.length) {
    box.innerHTML = '<div class="empty">Tidak ditemukan. Pastikan data sudah diinput guru.</div>';
    return;
  }
  box.innerHTML = found.map(s => `
    <div class="list-item" style="cursor:pointer;" data-id="${s.id}">
      <div>
        <div class="title">${escapeHtml(s.nama)}</div>
        <div class="meta">Kelas: ${escapeHtml(s.kelas)}</div>
      </div>
      <div class="actions"><span class="badge">Lihat</span></div>
    </div>
  `).join('');
  box.querySelectorAll('.list-item').forEach(el => {
    el.addEventListener('click', () => tampilDetail(el.dataset.id));
  });
}

function tampilDetail(id) {
  const siswa = load(KEYS.siswa).find(s => s.id === id);
  if (!siswa) return;

  document.getElementById('panelCari').classList.add('hidden');
  document.getElementById('panelDetail').classList.remove('hidden');

  document.getElementById('detailNama').textContent = siswa.nama;
  document.getElementById('detailMeta').textContent =
    `Kelas ${siswa.kelas}`;

  // XP block
  const p = hitungProgres(id);
  const pct = Math.round((p.progress || 0) * 100);
  const xpBox = document.getElementById('detailXP');
  if (xpBox) {
    xpBox.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <span class="level-badge">Tahap ${p.level}</span>
        <strong style="color:#0ea5e9;">${p.totalXP} poin</strong>
      </div>
      <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;">Menuju tahap capaian berikutnya · ${pct}%</div>
      <div class="xp-bar-wrap"><div class="xp-bar" style="width:${pct}%"></div></div>
      <div class="score-grid" style="margin-top:14px;">
        <div class="score-box kog"><div class="lbl">Kognitif</div><div class="val">${p.kognitif ?? '—'}</div></div>
        <div class="score-box non"><div class="lbl">Non-kognitif</div><div class="val">${p.nonkognitif ?? '—'}</div></div>
        <div class="score-box xp"><div class="lbl">Poin Progres</div><div class="val">${p.totalXP}</div></div>
      </div>
    `;
  }

  // Jurnal
  const jurnal = load(KEYS.jurnal).filter(j => j.siswaId === id)
    .sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  const jBox = document.getElementById('detailJurnal');
  if (!jurnal.length) {
    jBox.innerHTML = '<div class="empty">Belum ada catatan observasi / nilai dari guru.</div>';
  } else {
    jBox.innerHTML = jurnal.map(j => `
      <div class="list-item">
        <div>
          <div class="meta">${formatDate(j.tanggal)}${j.mood ? ' · ' + escapeHtml(j.mood) : ''}</div>
          <div class="title">${escapeHtml(j.topik || 'Observasi')} ${nilaiBadge(j.nilai)}</div>
          <div class="desc">${escapeHtml(j.catatan)}</div>
        </div>
      </div>
    `).join('');
  }

  // Nilai manual
  const manual = load(KEYS.nilai).filter(n => n.siswaId === id)
    .sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  const mBox = document.getElementById('detailNilaiManual');
  if (mBox) {
    if (!manual.length) {
      mBox.innerHTML = '<div class="empty">Belum ada nilai manual tambahan.</div>';
    } else {
      mBox.innerHTML = manual.map(n => `
        <div class="list-item">
          <div>
            <div class="meta">${formatDate(n.tanggal)} · ${n.aspek === 'kognitif' ? 'Kognitif' : 'Non-kognitif'}</div>
            <div class="title">Skor ${n.skor} <span class="badge">${n.aspek}</span></div>
            <div class="desc">${escapeHtml(n.catatan || '')}</div>
          </div>
        </div>
      `).join('');
    }
  }

  // Kegiatan
  const kegiatan = load(KEYS.kegiatan).sort((a, b) => b.tanggal.localeCompare(a.tanggal)).slice(0, 15);
  const kBox = document.getElementById('detailKegiatan');
  if (!kegiatan.length) {
    kBox.innerHTML = '<div class="empty">Belum ada kegiatan tercatat.</div>';
  } else {
    kBox.innerHTML = kegiatan.map(k => `
      <div class="list-item">
        <div>
          <div class="meta">${formatDate(k.tanggal)} · ${escapeHtml(k.jenis)}</div>
          <div class="title">${escapeHtml(k.judul)}</div>
          <div class="desc">${escapeHtml(k.detail || '')}</div>
        </div>
      </div>
    `).join('');
  }
}

function kembali() {
  document.getElementById('panelDetail').classList.add('hidden');
  document.getElementById('panelCari').classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
  const auth = requireWali();
  if (!auth) return;

  document.getElementById('btnLogout').addEventListener('click', e => {
    e.preventDefault();
    logout();
  });

  document.getElementById('btnCari').addEventListener('click', cari);
  document.getElementById('cariInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); cari(); }
  });
  document.getElementById('btnKembali').addEventListener('click', e => {
    e.preventDefault();
    kembali();
  });

  // auto isi dari login
  if (auth.siswaId) {
    tampilDetail(auth.siswaId);
  } else if (auth.query) {
    const input = document.getElementById('cariInput');
    if (input) {
      input.value = auth.query;
      cari();
    }
  }
});
