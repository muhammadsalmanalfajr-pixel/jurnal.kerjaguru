# Smart Jurnal — Cloud Edition

Stack: GitHub + Netlify + Supabase.

## Setup sekali
1. Buka Supabase SQL Editor.
2. Jalankan `supabase_setup.sql`.
3. Di Supabase Authentication > Providers > Google, aktifkan Google OAuth dan isi Client ID/Secret dari Google Cloud.
4. Tambahkan URL Netlify kamu ke Authentication > URL Configuration > Redirect URLs.
5. Deploy folder `jurnal-guru-ai` ke Netlify.

Admin utama: `senakaevagarden@gmail.com`. Setelah akun tersebut mendaftar/login pertama kali, trigger database otomatis memberi role admin.

Jangan memasukkan database password atau service-role key ke frontend. Publishable key di `assets/js/supabase.js` memang ditujukan untuk client, sedangkan RLS adalah lapisan keamanan utama.
