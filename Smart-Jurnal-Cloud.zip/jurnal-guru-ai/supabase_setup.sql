-- Smart Jurnal Supabase setup
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  name text,
  role text not null default 'guru' check (role in ('guru','admin')),
  status text not null default 'active' check (status in ('active','blocked')),
  created_at timestamptz not null default now()
);

create table if not exists public.app_records (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('siswa','jurnal','nilai','kegiatan')),
  record_id text not null,
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(owner_id,kind,record_id)
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_user uuid references public.profiles(id) on delete set null,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and status='active');
$$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,email,name,role,status) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'name',split_part(new.email,'@',1)),case when lower(new.email)='senakaevagarden@gmail.com' then 'admin' else 'guru' end,'active') on conflict(id) do update set email=excluded.email;
  return new;
end;$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.app_records enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists profiles_self on public.profiles;
drop policy if exists profiles_admin_select on public.profiles;
drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_self on public.profiles for select using(id=auth.uid());
create policy profiles_admin_select on public.profiles for select using(public.is_admin());
create policy profiles_admin_update on public.profiles for update using(public.is_admin()) with check(public.is_admin());

drop policy if exists records_owner_all on public.app_records;
drop policy if exists records_admin_all on public.app_records;
create policy records_owner_all on public.app_records for all using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy records_admin_all on public.app_records for all using(public.is_admin()) with check(public.is_admin());

drop policy if exists audit_admin_select on public.audit_logs;
create policy audit_admin_select on public.audit_logs for select using(public.is_admin());

create index if not exists app_records_owner_kind_idx on public.app_records(owner_id,kind);
create index if not exists profiles_status_idx on public.profiles(status);

-- Admin utama (jika akun sudah pernah dibuat).
update public.profiles set role='admin',status='active' where lower(email)='senakaevagarden@gmail.com';

-- Portal wali yang lebih aman: akses memakai kode, bukan pencarian nama.
create table if not exists public.wali_access (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  student_id text not null,
  access_code text unique not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.wali_access enable row level security;
drop policy if exists wali_owner_all on public.wali_access;
create policy wali_owner_all on public.wali_access for all using(owner_id=auth.uid()) with check(owner_id=auth.uid());

create or replace function public.wali_lookup(p_code text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare a public.wali_access; result jsonb;
begin
  select * into a from public.wali_access where access_code=trim(p_code) and active=true limit 1;
  if not found then return jsonb_build_object('ok',false,'message','Kode wali tidak valid'); end if;
  select jsonb_build_object(
    'ok',true,
    'student', (select coalesce(data,'{}'::jsonb) || jsonb_build_object('id',record_id) from public.app_records where owner_id=a.owner_id and kind='siswa' and record_id=a.student_id limit 1),
    'jurnal', (select coalesce(jsonb_agg(coalesce(data,'{}'::jsonb) || jsonb_build_object('id',record_id)),'[]'::jsonb) from public.app_records where owner_id=a.owner_id and kind='jurnal' and data->>'siswaId'=a.student_id),
    'nilai', (select coalesce(jsonb_agg(coalesce(data,'{}'::jsonb) || jsonb_build_object('id',record_id)),'[]'::jsonb) from public.app_records where owner_id=a.owner_id and kind='nilai' and data->>'siswaId'=a.student_id),
    'kegiatan', (select coalesce(jsonb_agg(coalesce(data,'{}'::jsonb) || jsonb_build_object('id',record_id)),'[]'::jsonb) from public.app_records where owner_id=a.owner_id and kind='kegiatan')
  ) into result;
  return result;
end;$$;
revoke all on function public.wali_lookup(text) from public;
grant execute on function public.wali_lookup(text) to anon,authenticated;
